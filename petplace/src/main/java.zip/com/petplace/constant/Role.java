package com.petplace.constant;

public enum Role {
    USER, ADMIN
}
