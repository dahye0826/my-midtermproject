package com.petplace.constant;

public enum TargetType {
    POST,COMMENT,VISITEDPLACE
}
